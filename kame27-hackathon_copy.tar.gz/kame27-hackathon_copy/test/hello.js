var Hello = artifacts.require("Hello");

contract('Hello', function(accounts) {
  it("message", function(done) {
    var hello = Hello.deployed().then(function(instance) {
      console.log(instance.message);
      assert.isTrue(true);
      done();
    });
  });
});
